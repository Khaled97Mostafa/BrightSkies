public class Flight {
	private int flightNumber;
	private String countryOfDeparture;
	private String countryOfArrival;
	private String departureDate;
	private String departureTime;
	private String price;
	
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getCountryOfDeparture() {
		return countryOfDeparture;
	}
	public void setCountryOfDeparture(String countryOfDeparture) {
		this.countryOfDeparture = countryOfDeparture;
	}
	public String getCountryOfArrival() {
		return countryOfArrival;
	}
	public void setCountryOfArrival(String countryOfArrival) {
		this.countryOfArrival = countryOfArrival;
	}
	public String getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	
	
}
