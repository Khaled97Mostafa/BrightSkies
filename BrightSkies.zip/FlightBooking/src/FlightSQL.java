import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import com.mysql.*;

public class FlightSQL {
	public static Connection getConnection() {
		
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://127.0.0.1/flightinfo";
			con = DriverManager.getConnection(url,"root", "");
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return con;
	}
	
	public static int creat(Flight f) {
		int st=0;
		try {
			String sql = "INSERT INTO flightinfo (CountryofDeparture, CountryofArrival, DepartureDate, DepartureTime, Price) VALUES (?,?,?,?,?)";
			Connection con = FlightSQL.getConnection();
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1, f.getCountryOfDeparture());
			ps.setString(2, f.getCountryOfArrival());
			ps.setString(3, f.getDepartureDate());
			ps.setString(4, f.getDepartureTime());
			ps.setString(5, f.getPrice());
			
			st = ps.executeUpdate();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return st;
	}
	
	public static int update(Flight f) {
		int st=0;
		try {
			String sql = "UPDATE flightinfo SET CountryofDeparture=?,CountryofArrival=?,DepartureDate=?,DepartureTime=?,Price=? WHERE FlightNumber=?";
			Connection con = FlightSQL.getConnection();
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1, f.getCountryOfDeparture());
			ps.setString(2, f.getCountryOfArrival());
			ps.setString(3, f.getDepartureDate());
			ps.setString(4, f.getDepartureTime());
			ps.setString(5, f.getPrice());
			ps.setInt(6, f.getFlightNumber());
			
			st = ps.executeUpdate();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return st;
	}
	
	public static int delete(int flightNumber) {
		int st=0;
		try {
			String sql = "DELETE FROM flightinfo WHERE FlightNumber=?";
			Connection con = FlightSQL.getConnection();
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, flightNumber);
			
			st = ps.executeUpdate() ;
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return st;
	}
	
	public static Flight read(int flightNumber) {
		
		Flight f = new Flight();
		try {
			String sql = "SELECT * FROM flightinfo WHERE FlightNumber=?";
			Connection con = FlightSQL.getConnection();
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setInt(1, flightNumber);
			ResultSet resultSet = ps.executeQuery();
			
			if (resultSet.next()) {
				f.setFlightNumber(resultSet.getInt(1));
				f.setCountryOfDeparture(resultSet.getString(2));
				f.setCountryOfArrival(resultSet.getString(3));
				f.setDepartureDate(resultSet.getString(4));
				f.setDepartureTime(resultSet.getString(5));
				f.setPrice(resultSet.getString(6));
			}
			
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return f;
	}
	
	public static List<Flight> readAll() {
		List<Flight> list = new ArrayList<Flight>();
		
		try {
			String sql = "SELECT * FROM flightinfo";
			Connection con = FlightSQL.getConnection();
			PreparedStatement ps= con.prepareStatement(sql);

			ResultSet resultSet = ps.executeQuery();
			
			while (resultSet.next()) {
				Flight f = new Flight();
				f.setFlightNumber(resultSet.getInt(1));
				f.setCountryOfDeparture(resultSet.getString(2));
				f.setCountryOfArrival(resultSet.getString(3));
				f.setDepartureDate(resultSet.getString(4));
				f.setDepartureTime(resultSet.getString(5));
				f.setPrice(resultSet.getString(6));
				
				list.add(f);
			}
			
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
}
