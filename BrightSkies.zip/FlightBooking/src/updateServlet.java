

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateServlet")
public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public updateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.println("<h1> Update Flight INFO </h1>");
		String flightNumber = request.getParameter("flightNumber");
		int intFlightNumber = Integer.parseInt(flightNumber);
		
		Flight f = FlightSQL.read(intFlightNumber);
		
		pw.print("<head>");
		pw.print("<link href='css/bootstrap.min.css' rel='stylesheet'>");
		pw.print("</head>");
		pw.print("<body>");
		pw.print("<form action='UpdateServlet2' method='post'>");
		pw.print("<table>");
		pw.print("<tr><td></td><td><input name='flightNumber' value='"+f.getFlightNumber()+"'/></td></tr>");
		pw.print("<tr><td>Country Of Departure</td><td><input type='text' name='countryOfDeparture' value='"+f.getCountryOfDeparture()+"'/></td></tr>");
		pw.print("<tr><td>Country Of Arrival</td><td><input type='text' name='countryOfArrival' value='"+f.getCountryOfArrival()+"'/></td></tr>");
		pw.print("<tr><td>Departure Date</td><td><input type='date' name='departureDate' value='"+f.getDepartureDate()+"'/></td></tr>");
		pw.print("<tr><td>Departure Time</td><td><input type='time' name='departureTime' value='"+f.getDepartureTime()+"'/></td></tr>");
		pw.print("<tr><td>Price</td><td><input type='text' name='price' value='"+f.getPrice()+"'/></td></tr>");
		pw.print("</td></tr>");
		pw.print("<tr><td colspan='2'><input type='submit' value='submit'/></td></tr>");
		pw.print("/table");
		pw.print("</form>");
		pw.print("</body>");
		
	}


}
