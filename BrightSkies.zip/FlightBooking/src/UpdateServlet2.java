

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateServlet2")
public class UpdateServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UpdateServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String flightNumber = request.getParameter("flightNumber");
		int intFlightNumber = Integer.parseInt(flightNumber);
		String countryOfDeparture = request.getParameter("countryOfDeparture");
		String countryOfArrival = request.getParameter("countryOfArrival");
		String departureDate = request.getParameter("departureDate");
		String departureTime = request.getParameter("departureTime");
		String price=request.getParameter("price");
		
		Flight f = new Flight();
		
		f.setFlightNumber(intFlightNumber);
		f.setCountryOfDeparture(countryOfDeparture);
		f.setCountryOfArrival(countryOfArrival);
		f.setDepartureDate(departureDate);
		f.setDepartureTime(departureTime);
		f.setPrice(price);
		
		int i = FlightSQL.update(f);
		if (i>0) {
			response.sendRedirect("ViewServlet");
		}else {
			pw.println("<h2> Sorry no update created </h2>");
		}
	}

}
