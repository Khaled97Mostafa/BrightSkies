

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.print("<head>");
		pw.print("<link href='css/bootstrap.min.css' rel='stylesheet'>");
		pw.print("</head>");
		pw.print("<body>");
		
		pw.print("<a href='index.html' class='btn btn-info' role='button'>Add Flight</a>");
		pw.print("<h1> Available Flights </h1>");
		
		List<Flight> list = FlightSQL.readAll();
		
		pw.print("<table border='1' width='100%'");
		pw.print("<tr> <th>Flight Number</th> <th>Country Of Departure</th> <th>Country Of Arrival</th> <th>Departure Date</th> <th>Departure Time</th> <th>Price</th> <th>Edit</th> <th>Delete</th> </tr>");
		
		for (Flight f:list) {
			pw.print("<tr><td>"+f.getFlightNumber()+"</td><td>"+f.getCountryOfDeparture()
			+"</td><td>"+f.getCountryOfArrival()+"</td><td>"+f.getDepartureDate()
			+"</td><td>"+f.getDepartureTime()+"</td><td>"+f.getPrice()+"</td><td><a href='updateServlet?flightNumber="+f.getFlightNumber()+"'>edit</a></td> <td><a href='deleteServlet?flightNumber="
			+f.getFlightNumber()+"'>delete</a></td></tr>");
		}
		
		pw.print("</table>");
		pw.print("</body>");
	}

}
