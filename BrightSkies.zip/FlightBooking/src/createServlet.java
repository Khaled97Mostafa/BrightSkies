

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/createServlet")
public class createServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public createServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String countryOfDeparture = request.getParameter("countryOfDeparture");
		String countryOfArrival = request.getParameter("countryOfArrival");
		String departureDate = request.getParameter("departureDate");
		String departureTime = request.getParameter("departureTime");
		String price=request.getParameter("price");
		
		Flight f = new Flight();
		f.setCountryOfDeparture(countryOfDeparture);
		f.setCountryOfArrival(countryOfArrival);
		f.setDepartureDate(departureDate);
		f.setDepartureTime(departureTime);
		f.setPrice(price);
		
		int i = FlightSQL.creat(f);
		
		if (i>0) {
			pw.println("<h2> <br><br><br> Saved Successfully !! </h2>");
			request.getRequestDispatcher("index.html").include(request, response);
		}else {
			pw.println("<h2> Sorry not saved </h2>");
		}
		
	}

}
